using PaymentApi.Configuration;

namespace PaymentApi.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {
    
    }
}